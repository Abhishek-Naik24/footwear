import React from "react";

function Loader(){
    return(
        <>
            <div class="colorlib-loader"></div>
        </>
    )
}

export default Loader;